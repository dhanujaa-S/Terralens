import json
import logging
from typing import Optional
import requests
import streamlit as st
import streamlit.components.v1 as components

from modules.database import get_conn

logger = logging.getLogger(__name__)

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
NOMINATIM_HEADERS = {"User-Agent": "TerraLens-SIH2026-LandRecords"}


def geocode_location(
    village: str,
    tehsil: str = "",
    district: str = "",
    state: str = "India",
) -> Optional[dict]:
    """
    Convert village/district name to GPS coordinates using OpenStreetMap Nominatim.
    Free API — no key required.
    Builds query from: village, tehsil, district, state
    Restricts to India only (countrycodes=in).
    Returns dict with keys: lat, lng, display_name, osm_type
    Returns None if location not found or on any network error.
    """
    query_parts = [p for p in [village, tehsil, district, state] if p and p.strip()]
    if not query_parts:
        logger.warning("geocode_location called with all empty strings")
        return None

    query = ", ".join(query_parts)
    params = {
        "q": query,
        "format": "json",
        "limit": 1,
        "countrycodes": "in",
    }

    try:
        response = requests.get(
            NOMINATIM_URL,
            params=params,
            headers=NOMINATIM_HEADERS,
            timeout=5,
        )
        results = response.json()
        if not results:
            logger.warning(f"Nominatim: no results for '{query}'")
            return None

        r = results[0]
        coords = {
            "lat": float(r["lat"]),
            "lng": float(r["lon"]),
            "display_name": r.get("display_name", query),
            "osm_type": r.get("type", ""),
        }
        logger.info(f"Geocoded '{query}' -> {coords['lat']:.4f}, {coords['lng']:.4f}")
        return coords
    except requests.Timeout:
        logger.warning(f"Nominatim timeout for '{query}'")
        return None
    except Exception as e:
        logger.error(f"geocode_location error for '{query}': {e}")
        return None


def save_coordinates(record_id: int, lat: float, lng: float) -> bool:
    """
    Save GPS coordinates to the land_records table in SQLite.
    Updates latitude and longitude for the given record_id.
    Returns True on success, False on any database error.
    """
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE land_records SET latitude=?, longitude=? WHERE id=?",
                (lat, lng, record_id),
            )
        logger.info(
            f"Saved coordinates for record {record_id}: "
            f"lat={lat:.6f}, lng={lng:.6f}"
        )
        return True
    except Exception as e:
        logger.error(f"save_coordinates error for record {record_id}: {e}")
        return False


def auto_geotag_record(
    record_id: int,
    village: str,
    tehsil: str = "",
    district: str = "",
    state: str = "",
) -> bool:
    """
    Full auto geo-tagging pipeline:
    1. Geocode village+district using Nominatim
    2. Save lat/lng to DB
    Called automatically from upload_ui.py after every record is saved.
    Returns True if geocoding and saving succeeded, False otherwise.
    Note: pass empty string "" for unknown fields — never pass None.
    """
    coords = geocode_location(
        village=village,
        tehsil=tehsil,
        district=district,
        state=state or "India",
    )
    if coords is None:
        logger.warning(
            f"Could not geocode record {record_id}: "
            f"village='{village}', district='{district}'"
        )
        return False
    return save_coordinates(record_id, coords["lat"], coords["lng"])


def render_map(
    records: list,
    zoom: int = 6,
    center_lat: float = 20.5937,
    center_lng: float = 78.9629,
) -> None:
    """
    Render an interactive Leaflet.js map in Streamlit showing all geo-tagged records.
    records: list of dicts from get_all_records() — each must have:
      id, landowner_name, village, district, khasra_number, status,
      latitude, longitude
    Marker colors:
      green  = verified
      orange = pending
      red    = rejected
    Uses OpenStreetMap tiles — no API key required.
    Renders via st.components.v1.html().
    """
    geo_records = [
        r for r in records
        if r.get("latitude") and r.get("longitude")
    ]
    if not geo_records:
        st.info(
            "No geo-tagged records yet. "
            "Upload documents to automatically tag their locations on the map."
        )
        return

    markers_js_lines = []
    for r in geo_records:
        lat = r["latitude"]
        lng = r["longitude"]
        status = r.get("status", "pending")
        color = {"verified": "green", "rejected": "red"}.get(status, "orange")
        owner = str(r.get("landowner_name", "N/A"))
        village = str(r.get("village", "N/A"))
        dist = str(r.get("district", "N/A"))
        khasra = str(r.get("khasra_number", "N/A"))
        rec_id = r.get("id", "")
        popup_html = (
            f"<b>Record #{rec_id}</b><br>"
            f"Owner: {owner}<br>"
            f"Village: {village}<br>"
            f"District: {dist}<br>"
            f"Khasra: {khasra}<br>"
            f"Status: <span style=\"color:{color};font-weight:bold\">{status}</span>"
        )
        popup_js_literal = json.dumps(popup_html)
        marker_js = (
            f"L.circleMarker([{lat}, {lng}], {{"
            f"radius: 8, color: '{color}', fillColor: '{color}', "
            f"fillOpacity: 0.8, weight: 2"
            f"}}).addTo(map).bindPopup({popup_js_literal});"
        )
        markers_js_lines.append(marker_js)

    all_markers_js = "\n    ".join(markers_js_lines)

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<link
  rel="stylesheet"
  href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
  body {{ margin: 0; padding: 0; }}
  #map {{ width: 100%; height: 500px; }}
  .legend {{
    background: white;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 12px;
    line-height: 2;
    box-shadow: 0 1px 5px rgba(0,0,0,0.3);
  }}
</style>
</head>
<body>
<div id="map"></div>
<script>
  var map = L.map('map').setView([{center_lat}, {center_lng}], {zoom});
  L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }}).addTo(map);

  {all_markers_js}

  var legend = L.control({{position: 'bottomright'}});
  legend.onAdd = function(map) {{
    var div = L.DomUtil.create('div', 'legend');
    div.innerHTML =
      '<b>Land Records</b><br>' +
      '<span style="color:green">&#9679;</span> Verified<br>' +
      '<span style="color:orange">&#9679;</span> Pending<br>' +
      '<span style="color:red">&#9679;</span> Rejected';
    return div;
  }};
  legend.addTo(map);
</script>
</body>
</html>"""

    components.html(html, height=520)
    st.caption(
        f"Showing {len(geo_records)} geo-tagged records "
        f"out of {len(records)} total records."
    )


if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO)

    print("Testing Module 11 — gis_module.py")
    print("=" * 60)

    print("\nTest 1: geocode_location() — real Nominatim API call")
    result = geocode_location("Khed", "Haveli", "Pune", "Maharashtra")
    if result:
        print(f"  lat:          {result['lat']}")
        print(f"  lng:          {result['lng']}")
        print(f"  display_name: {result['display_name'][:60]}...")
        assert 15.0 < result["lat"] < 22.0, "Latitude out of Maharashtra range"
        assert 70.0 < result["lng"] < 80.0, "Longitude out of Maharashtra range"
        print("  Coordinates in expected range OK")
    else:
        print("  WARNING: geocoding returned None")
        print("  Check internet connection or Nominatim availability")

    print("\nTest 2: geocode_location() with unknown village")
    none_result = geocode_location("ZZZNONEXISTENTVILLAGE999", "", "", "India")
    print(f"  Unknown village returns None: {none_result is None} OK")

    print("\nTest 3: auto_geotag_record() — needs DB record to exist")
    print("  Skipping DB test in unit mode (needs seeded database)")
    print("  This will be tested when running the full app")

    print("\n" + "=" * 60)
    print("Module 11 — gis_module.py OK")
